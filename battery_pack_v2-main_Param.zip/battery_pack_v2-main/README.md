# Battery Pack

OpenModelica model for a water cooled battery pack.

The repository comprises:
- the openmodelica model itself
- it's [documentation](doc/model_description.md)
- scripts for postprocessing and visualisation

The model is intended to be part of an optimisation loop, with
geometry creation in the loop. The geometry is created with 
Rhino/Grasshopper, and managed in a [Sebastian's repository](https://github.com/slzefzal/KISS-Battery).

[Specification of inputs and outputs](doc/geom_spec.md) of the geometry creation process.

## Running Modelica

tba

## Postprocessing

### Geometry Visualisation

There is a small program `vis3d.py` that loads 3d models and displays them in a browser.
Some example data are provided in the `data` directory.

Requirements:
``` 
dash
plotly
meshio
```

Usage: 

run `python vis3d.py <path_to_directory_where_obj_files_live>` on the command line, 
then open the displayed link (usually `http://127.0.0.1:8050/`) in your browser.


### Results Visualisation

The `postproc.py` module contains functions that extract relevant data from Modelica
result files.

`plots_plotly.py` and `plots_mpl.py` contain code that generate 
[plotly](https://plotly.com/python/) resp. 
[matplotlib](https://matplotlib.org/) plots for these results.

`vis_app.py` is a small [dash](https://dash.plotly.com/) application that visualises results 
for a single modelica run as an html page (it launches a local web server).

Usage:

`python vis_app.py <path_to_modelica_result.mat> <path_to_metadata.json>`

The `metadata.json` must contain at least the _channel_width_ and _channel_height_ dimensions, see this [example](data/meta_ex.json).