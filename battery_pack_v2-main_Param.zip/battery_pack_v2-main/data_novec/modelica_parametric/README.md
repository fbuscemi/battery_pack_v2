# Parameteric model

Compiled modelica models are parametetric (can provide scalar 
parameters via command line). Array size (number of cells) is 
fixed, so we compile a separate model for each ncells value. 

What to do:
- as a test, compile `Kiss1.mo` and see if it works. 
- run `build.py` 
- remove *.c, *.h, *.o, *.makefile
- keep the executables and the .json, .xml files. 
  They are needed for simulation.

`build.py` ... python script that generates .mo and .mos files,
then compiles multiples modelica models. 

`Kiss_tmpl.mo`  ... Python string template 
`Kiss1.mo` ... Example .mo file, for testing

`CooledPouchCell.mo`, `PouchCellAndPipe.mo`, `PouchZelle.mo`,  `Wand.mo` ... modelica files for subclasses

The model paramaters and default values are listed below. 
The default values represent the original KISS design.
    
    // global parameters
    parameter Real m_flow = 0.0037;
    
    // the cell itself
    parameter Real C_quartercell = 36.3; 
    parameter Real k_cell = 3.311;

    // the pipe cover (wall)
    parameter Real t_cover = 0.002;
    parameter Real c_cover = 888.0;
    parameter Real k_cover = 220.0;
    parameter Real rho_cover = 2700.0;
    parameter Real area_cover = 0.000344;

    // channel parameters
    parameter Real area_channel = 3.2e-5;
    parameter Real cell_width = 0.043;
    parameter Real perim_channel = 0.024;
    parameter Real roughness = 0.0;

    // parameters of walls (plate) btwn channels
    parameter Real t_plate = 0.032;
    parameter Real area_plate = 0.000172;
    parameter Real c_plate = 888.0;
    parameter Real k_plate = 222.0;
    parameter Real rho_plate = 2700.0;  


__NOTE:__ cell_width is defined as a parameter here, Modelica tells us however that we can't change it. 


    stdout            | warning | It is not possible to override the following quantity: cell_width
    |                 | |       | It seems to be structural, final, protected or evaluated or has a non-constant binding.


### Compiled models

- on google drive
- Naming: `Kiss9x8` has 9 racks, each rack has 2x8 cells.


### How to use the compiled models

- `Kiss9x8` runs the 9x8 model with default parameters

- `Kiss9x8 -override m_flow=0.01,t_cover=0.001` runs the 9x8 model with
  custom values for m_flow, t_cover

- Recommended: `Kiss9x8 -overrideFile <infile> -r <outfile> -outputPath <dir>` runs the 9x8 model 
  with custom values for all parameters. 
  `<dir>` is the directory where you want the results stored.
  `<outfile>` defines the name of the result file (<outfile>_res.mat). Use simid for naming.
  `<datafile>` is a text file looking like this: 
  ```
    m_flow=0.0037
    C_quartercell=36.3 
    k_cell=3.311
    t_cover=0.002
    c_cover=888.0
    k_cover=220.0
    rho_cover=2700.0
    area_cover=0.000344
    area_channel=3.2e-5
    perim_channel=0.024
    t_plate=0.032
    area_plate=0.000172
    c_plate=888.0
    k_plate=222.0
    rho_plate=2700.0
    ```  

