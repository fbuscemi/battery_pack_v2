# Run this app with `python app.py` and
# visit http://127.0.0.1:8050/ in your web browser.

import argparse 
import os
import pandas as pd
import json

import dash
import dash_core_components as dcc
import dash_html_components as html
import dash_table

import DyMat
from . import postproc
from . import plots_plotly as plp




external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

app = dash.Dash(__name__, external_stylesheets=external_stylesheets)

# TODO: use argparse or somethng else to get filename
# get path to obj files from command line
parser = argparse.ArgumentParser(
    description="Visualise a modelica run.")
parser.add_argument('matfile', type=str, 
    help="path to result file (.mat)")
parser.add_argument('metadata', type=str, 
    help="path to metadata file (.json)")
parser.add_argument('--tmax', type=int, default=1200,
    help="max display time")
parser.add_argument('--plotevery', type=int, default=10,
    help="plot every nth data point")

args = parser.parse_args()
# make sure files exist
assert os.path.exists(args.matfile), f"modelica result file does not exist: {args.matfile}"
assert os.path.exists(args.metadata), f"metadata file does not exist: {args.metadata}"

# read result
modelica_result = DyMat.DyMatFile(args.matfile)

# -----------------------------------------
# Header and summary
# ----------------------------------------- 

# summary table
with open(args.metadata, encoding="utf-8") as fp:
    meta = json.load(fp)
df = postproc.extract_scalar_values(modelica_result, **meta)

# Fluid temperatures vs. time, as facet plot
df_tcell = postproc.extract_tcell(modelica_result)
fig_tcell = plp.plot_tcell(df_tcell, tmax=args.tmax, step=args.plotevery, degC=True)

# Fluid temperatures vs. time, as facet plot
df_tfluid = postproc.extract_tfluid(modelica_result)
fig_tfluid = plp.plot_tfluid(df_tfluid, tmax=args.tmax, step=args.plotevery, degC=True)

# Temperature of walls between pipes vs. time, as facet plot
df_twall = postproc.extract_twall(modelica_result)
fig_twall = plp.plot_twall(df_twall, tmax=args.tmax, step=args.plotevery, degC=True)

# Heat flow in walls between pipes vs. time, as facet plot
df_qwall = postproc.extract_qwall(modelica_result)
fig_qwall = plp.plot_qwall(df_qwall, tmax=args.tmax, step=args.plotevery)

# Heat flow from battery cells to fluids
df_qpipe = postproc.extract_qpipe(modelica_result)
fig_qpipe = plp.plot_qpipe(df_qpipe, tmax=args.tmax, step=args.plotevery)

# Fluid temperature vs. pipe length
fig_tfluid_s = plp.plot_tfluid_s(df_tfluid, degC=True, pos=2)

# pressure loss
df_dp = postproc.extract_deltap(modelica_result)
fig_dp = plp.plot_deltap(df_dp, tmax=args.tmax, step=args.plotevery)

# power / energy
# FIXME: remane this to power!
df_ener = postproc.extract_energies(modelica_result)
fig_ener = plp.plot_energies(df_ener, tmax=args.tmax, step=args.plotevery)

# -----------------
# Page layout 
# -----------------
app.layout = html.Div([
    # Header
    html.H1(children='Battery Pack Results'),
    html.P(children=f"Result file: {args.matfile}"),
    html.P(children=f"Metadata file: {args.metadata}"),
    # Summary
    html.H2(children="Summary"),
    dash_table.DataTable(id='table',
        columns=[{"name": i, "id": i} for i in df.columns],
        data=df.to_dict('records')),
    # Cell temps
    html.H2(children="Cell Temperatures"),
    dcc.Graph(
        id='tcell_vs_t',
        figure=fig_tcell
    ),
    html.H2(children="Fluid Temperatures"),
    dcc.Graph(
        id='tfluid_vs_t',
        figure=fig_tfluid
    ), 
    html.H2(children="Temperature in walls between pipes"),
    dcc.Graph(
        id='twall_vs_t',
        figure=fig_twall
    ), 
    html.H2(children="Heat flow in walls between pipes"),
    html.P(children="port a is to upper pipe, port b to lower pipe"),
    dcc.Graph(
        id='qwall_vs_t',
        figure=fig_qwall
    ),     
    html.H2(children="Heat flow from battery cells to pipes"),
    dcc.Graph(
        id='qpipe_vs_t',
        figure=fig_qpipe
    ),  
    html.H2(children="Fluid temperature vs. pipe length"),
    dcc.Graph(
        id='tfluid_vs_s',
        figure=fig_tfluid_s
    ),  
    html.H2(children="Pressure loss"),
    dcc.Graph(
        id='dp_vs_t',
        figure=fig_dp
    ),  
    html.H2(children="Power"),
    dcc.Graph(
        id='power_vs_t',
        figure=fig_ener
    ),          
])

#if __name__ == '__main__':
app.run_server(debug=True)

