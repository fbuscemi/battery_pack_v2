# data extraction, for KISS1 model

import numpy as np
import pandas as pd
import re

# Properties of pure water at atmospheric pressure and 20°C
# https://onlinelibrary.wiley.com/doi/pdf/10.1002/9781118534892.app2
# TODO: replace this by something better, and add temperature depencence 
# for at least the viscosity

class Water:
    rho = 998.2  # density, kg/m**3
    eta = 0.001002  # dynamic viscosity, Pa s  --> at 50°C: only 0.0005471
    cp = 4183 # J/kgK
    k = 0.5861 # W/mK
    Pr = 7.152   # at 50°: 3.628

class Novec7000:
    # https://multimedia.3m.com/mws/media/1438117O/3m-novec-7000-engineered-fluid-tech-sheet.pdf, abgerufen am 16.04.2021
    # properties at 25°C
    # kinematic viscosity \nu = 0.32e-6 m**2/s
    # dynamic viscosity \eta = \nu \rho = 0.32e-6 * 1400 = 0.000448
    # FIXME: Siedepunkt: 34 °C -> da wird's kompliziert!
    rho = 1400  # density, kg/m**3
    eta = 0.000448  # dynamic viscosity, Pa s 
    cp = 1300 # Specific heat, J/(kg K)
    k = 0.075 # W/(m K), thermal conductivity
    Pr = np.nan   # Prandtl number, TODO

FLUIDS = {"Water": Water, "Novec7000": Novec7000}

def kelvin_to_celsius(x):
    return x - 273.16


def reynolds(eta, rho, v, d):
    """Return Reynolds number"""
    return rho*v*d/eta


def dia_hydr_rect(w, h):
    """Return hydraulic diameter of a rectangular pipe, dh = 4*A/P, 
    where A = w*h is the area and P = 2*(w+h) is the perimeter.

    Note: Computing the Reynolds number for very flat pipes with this is 
    not a good approximation. 

    See https://de.wikipedia.org/wiki/Hydraulischer_Durchmesser
    """

    a = w*h
    p = 1*(w+h)
    return 4*a/p


def extract_tcell(res):
    """
    Return a dataframe containing individual cell temperatures.
    Parameters:    
    - res: a DyMat file object
    Returns: 
    - df: a pandas dataframe. columns: 
      - t: time (s), 
      - Tcell: cell temperature (K)
      - TcellC: cell temperature (C)
      - i
      - j
      - k
    """
    
    # regex pattern
    pat = r'pouchCellAndPipe\[(\d+)\]\.cooledPouchCell(\d+)\.pouchZelle(\d+).heatCapacitor\.T'

    arrs = []
    for varname in res.names():
        m = re.match(pat, varname)
        if m:
            # shape (4, N)
            arr = res.getVarArray([varname], withAbscissa=True)
            df_ = pd.DataFrame(data=arr.T, index=None, columns=['t', 'Tcell'])
            df_['i'] = int(m.group(1)) 
            df_['j'] = int(m.group(2))
            df_['k'] = int(m.group(3))
            df_['TcellC'] = df_['Tcell'].apply(kelvin_to_celsius)
            arrs.append(df_)  
    return pd.concat(arrs, ignore_index=True)



def extract_tfluid(res):
    """
    Return a dataframe containing fluid temperatures.
    
    """
    
    # search for stuff like this: `pouchCellAndPipe0.pipe0.mediums[1].T`
    # mediums\[k\] is the medium property at position k along the pipe. 
    # The number of positions is defined by `nNodes` in the modelica input for DynamicPipe.
    # parameters: bar i, pipe j, pos p

    pat = r"pouchCellAndPipe\[(\d+)\]\.pipe(\d+)\.mediums\[(\d+)\]\.T$"

    arrs = []
    for varname in res.names():
        m = re.match(pat, varname)
        if m:
            arr = res.getVarArray([varname]) 
            df_ = pd.DataFrame(data=arr.T, index=None, columns=['t', 'Tfluid'])
            df_['bar'] = int(m.group(1))
            df_['pipe'] = int(m.group(2))
            df_['pos'] = int(m.group(3))
            df_['TfluidC'] = df_['Tfluid'].apply(kelvin_to_celsius)
            arrs.append(df_)
    return pd.concat(arrs, ignore_index=True)



def extract_twall(res):
    """Return a dataframe containing wall (between pipes) temperatures."""
    pat = r'pouchCellAndPipe\[(\d+)\]\.wand(\d+)\.T\[1\]'

    arrs = []
    for varname in res.names():
        m = re.match(pat, varname)
        if m:
            arr = res.getVarArray([varname]) 
            df_ = pd.DataFrame(data=arr.T, index=None, columns=['t', 'Twall'])
            df_['bar'] = int(m.group(1))
            df_['wall'] = int(m.group(2))
            df_['TwallC'] = df_['Twall'].apply(kelvin_to_celsius)
            arrs.append(df_) 
    return pd.concat(arrs, ignore_index=True)


def extract_qwall(res, every=1):
    """Return a dataframe containing heat flow between pipes."""

    # port a: top, port b: bottom ??? 
    pat = r'pouchCellAndPipe\[(\d+)\]\.wand(\d+)\.heatPort_([ab])\[1\].Q_flow'
    arrs = []

    for varname in res.names():
        m = re.match(pat, varname)
        if m:
            arr = res.getVarArray([varname]) 
            df_ = pd.DataFrame(data=arr.T, index=None, columns=['t', 'Q_flow'])
            df_['bar'] = int(m.group(1))
            df_['wall'] = int(m.group(2))
            df_['port'] = m.group(3)
            arrs.append(df_)
    return pd.concat(arrs, ignore_index=True)


def extract_qpipe(res):
    """Return a dataframe containing heat flow from cells to fluid."""
    # Qpipe is the accumulated heat flow from forward and aft cells (k=0 and k=1)
    
    pat = r'pouchCellAndPipe\[(\d+)\]\.cooledPouchCell(\d+)\.Qpipe\.Q_flow'
    arrs = []

    for varname in res.names():
        m = re.match(pat, varname)
        if m:
            arr = res.getVarArray([varname]) # shape (2, num_time_steps)
            df_ = pd.DataFrame(data=arr.T, index=None, columns=['t', 'Q_flow'])
            df_['i'] = int(m.group(1))
            df_['j'] = int(m.group(2))
            arrs.append(df_)
    return pd.concat(arrs, ignore_index=True)


# wir können verschiedene Drücke messen
# (res.description("pouchCellAndPipe0.pipe3.mediums[1].p"),
# res.description("pouchCellAndPipe0.pipe0.port_a.p"),
# res.description("KuehlmediumTempIn.port_a.p"))

def extract_deltap(res):
    """Return a dataframe containing difference om pressure between inflow and outflow (Pa)."""

    arr = res.getVarArray(["KuehlmediumTempIn.port_a.p"], withAbscissa=True)
    dfpl = pd.DataFrame(arr.T, columns=["t", "pin"])

    # pressure is constant (ambient), and the result is a 2x2 array
    arr = res.getVarArray(["KuehlmediumTempOut.port_a.p"], withAbscissa=True)
    pamb = arr[1,-1]
    dfpl['pout'] = pamb
    dfpl['dp'] = dfpl['pin'] - dfpl['pout']
    return dfpl


def extract_energies(res):
    """Return a dataframe containing energy balance: heat generated in cells, 
    enthalpy of inflow and outflow, and difference (= stored heat?)
    """
    
    # cells
    pat_qgen = r'pouchCellAndPipe\[(\d+)\]\.cooledPouchCell(\d+)\.pouchZelle(\d+)\.heatFlowSensor_vorHeatCapacitor\.port_a\.Q_flow'
    varnames = [s for s in res.names() if re.match(pat_qgen, s)]
    arr = res.getVarArray(varnames) 
    dfc = pd.DataFrame(data={"t": arr[0], "Qdot_gen": arr[1:].sum(axis=0)})
    # enthalpy
    arr = res.getVarArray(["pouchCellAndPipe[1].pipe0.H_flows[1]", 
                           "pouchCellAndPipe[1].pipe3.H_flows[1]"], withAbscissa=True)
    dfe = pd.DataFrame(arr.T, columns=["t", "Hdot_in", "Hdot_out"])
    df = pd.merge(dfc, dfe, on="t", how="inner")
    # stored
    df["Qdot_store"] = df.Qdot_gen + df.Hdot_in + df.Hdot_out
    # FIXME: some values are duplicate, even after drop (t = 0..2000, but 2003 rows)
    return df.drop_duplicates(subset="t").reset_index(drop=True)

# TODO: save template as json?
# template for tabular result summary
DESCRIPTION = {
    #"simu_id": {"unit": "N/A", "symbol": "N/A", "description": "simulation model id"},
    "simid": {"unit": "N/A", "symbol": "N/A", "description": "simulation model id"},
    #"geom_id": {},

    "C_quartercell": {"unit": "J/K", "symbol": "$C_{cell}$", "description": "Heat capacity of a quarter cell"},
    "k_contact": {},
    "c_wall": {},
    "k_wall": {},
    "rho_wall": {},
    "c_plate": {},
    "k_plate": {},
    "rho_plate": {},
    "cell_width": {},
    #"cell_dist": {},
    'nracks': {"unit": "1", "symbol": "$n_r$", "description": "number of racks/modules in a battery pack"},
    'ncells': {"unit": "1", "symbol": "$n_c$", "description": "number of cells per rack"},
    'channel_width': {"unit": "m", "symbol": "$w_c$", "description": "cooling channel width"},
    'channel_height': {"unit": "m", "symbol": "$h_c$", "description": "cooling channel height"},
    'twall': {"unit": "m", "symbol": "$t_w$", "description": "cooling channel wall thickness"},
    'channel_dist': {"unit": "m", "symbol": "$d_c$", "description": "distance between cooling channels"},
    "area_c": {"unit": "m²", 
               "symbol": "$A_c$", 
               "description": "Cross section area of fluid channel"},
    "tend": {"unit": "s", 
             "symbol": "$t_{end}$",
             "description": "Maximum simulation time"},
    "T_inflow": {"unit": "K",
                      "symbol": "$T_{in}$",
                      "description": "Temparature of medium at inflow"},
    "mdot_inflow": {"unit": "kg/s", 
                    "symbol": "$\dot{m}_{in}$",
                    "description": "Mass flow rate of cooling fluid in one rack"},
    "Vdot": {"unit": "m³/s", 
             "symbol": "$\dot{V}_{in}$",
             "description": "Volume flow rate of cooling fluid at inflow in one rack"},
    "v": {"unit": "m/s", 
          "symbol": "$v$",
          "description": "fluid velocity at inflow"},
    "dp_max": {"unit": "Pa",
               "symbol": "$\Delta p_{max}$",
               "description": "Maximum pressure loss (over time) between outflow and inflow of one rack"},
    "Pmax": {"unit": "W", 
             "symbol": "$P_{max}$",
             "description": "Maximum (over time) pump power required to push " +
                                         "the fluid through one rack"},
    "Qgen": {"unit": "J", 
             "symbol": "$Q_{gen}$",
             "description": "Heat generated by battery cells during discharge and charge, in one rack"},
    "T_cellmax": {"unit": "K",
                   "symbol": "$T_{cell,max}$",
                   "description": "Maximum cell temperature (over all cells, all time steps)"},
    "t21": {"unit": "s", 
            "symbol": "$t_{21}$",
            "description": "Time until temperature of last cell has cooled down to 21°C"},
    "tpeak": {"unit": "s", 
            "symbol": "$t_{peak}$",
            "description": "Time of maximum cell temperature"},    
    "T_cell1000": {"unit": "K", 
                    "symbol": "$T_{cell,1000s}$",
                    "description": "Temperature of hottest cell after 1000 s"},
    "dhyd": {"unit": "m", 
             "symbol": "$d_{hyd}$",
             "description": "Hydraulic diameter of fluid channel"},
    "Re": {"unit": "1", 
           "symbol": "$Re$",
           "description": "Reynolds number of fluid flow at inflow, based on " +
                                       "constant visosity of water at 20°C"}
}


# TODO: re-write that (make it easier to add new metadata)
def extract_scalar_values(res, channel_width=np.nan, channel_height=np.nan,
                          assy_id="", simu_id="", geom_id="", fluid_name="Water",
                          nracks=None, ncells=None, channel_dist=np.nan,
                          twall=np.nan, cell_width=np.nan, cell_dist=np.nan, **kwargs):
    """Return a dictionary containing scalar values"""
    
    
    fluid = FLUIDS[fluid_name]
    
    dfpl = extract_deltap(res)
    dfener = extract_energies(res)
    dfcell = extract_tcell(res)
    
    area_c = channel_width*channel_height
    tend = res.abscissa(1, valuesOnly=True)[-1]
    T_inflow = res.getVarArray(["boundary0.T"], withAbscissa=False)[0, 0]
    mdot = res.getVarArray(["boundary0.m_flow"], withAbscissa=False)[0, 0]
    dp_max = dfpl.query("t > 0").dp.max()
    Vdot = mdot/fluid.rho
    # time when last cell drops below 21°C
    T = dfcell.groupby("t", as_index=False).Tcell.max()        # max over all cells
    t_peak = T.t.loc[T.Tcell.idxmax()]                         # time of peak temp
    t_21 = T.query(f"t>{t_peak} & Tcell<{21+273.15}").t.min()  # time when worst cell is below 21 again
    T_1000 = T.query("t == 1000").Tcell.values[0]
    v = Vdot/area_c
    dhyd = dia_hydr_rect(channel_width, channel_height)
    
    scalars = DESCRIPTION.copy()
    #scalars['assy_id']['value'] = assy_id
    #scalars['simu_id']['value'] = simu_id
    #scalars['geom_id']['value'] = geom_id
    scalars['channel_width']['value'] = channel_width
    scalars['channel_height']['value'] = channel_height
    scalars['nracks']['value'] = nracks
    scalars['ncells']['value'] = ncells
    scalars['channel_dist']['value'] = channel_dist
    scalars['twall']['value'] = twall
    #scalars['cell_width']['value'] = cell_width
    #scalars['cell_dist']['value'] = cell_dist
    scalars['area_c']['value'] = area_c
    scalars['tend']['value'] = tend
    scalars['T_inflow']['value'] = T_inflow
    scalars['mdot_inflow']['value'] = mdot
    scalars['Vdot']['value'] = Vdot
    scalars['v']['value'] = v
    scalars['dp_max']['value'] = dp_max
    scalars['Pmax']['value'] = dfpl.query("t > 0").dp.max()*Vdot
    scalars['Qgen']['value'] = dfener.Qdot_gen.sum()
    scalars['T_cellmax']['value'] = dfcell.Tcell.max()
    scalars['t21']['value'] = t_21
    scalars['tpeak']['value'] = t_peak
    scalars['T_cell1000']['value'] = T_1000
    scalars['dhyd']['value'] = dhyd
    scalars['Re']['value'] = reynolds(fluid.eta, fluid.rho, v, dhyd)
    
    # can turn this back to dict with `d.to_dict(orient='index')` 
    return pd.DataFrame.from_dict(scalars, orient='index')


# TODO: re-write that (make it easier to add new metadata)
def extract_scalar_values2(res, channel_width=np.nan, channel_height=np.nan,
                          assy_id="", geom_id="", simid="", fluid_name="Water",
                          nracks=9, ncells=8, channel_dist=np.nan, area_channel=np.nan,
                          t_cover=np.nan, cell_width=np.nan, cell_dist=np.nan, **kwargs):
    """Return a dictionary containing scalar values"""
    
    fluid = FLUIDS[fluid_name]
    
    dfpl = extract_deltap(res)        # pressure loss
    dfener = extract_energies(res)    # energies
    dfcell = extract_tcell(res)       # cell temperatures
    T_inflow = res.getVarArray(["boundary0.T"], withAbscissa=False)[0, 0]
    mdot = res.getVarArray(["boundary0.m_flow"], withAbscissa=False)[0, 0]
    Vdot = mdot/fluid.rho
    T = dfcell.groupby("t", as_index=False).Tcell.max()        # max over all cells
    
    scalars = {} 
    scalars['simid'] = simid
    scalars['tend'] = res.abscissa(1, valuesOnly=True)[-1]
    scalars['T_inflow'] = T_inflow
    scalars['Vdot'] = Vdot
    scalars['v'] = Vdot/area_channel
    scalars['dp_max'] = dfpl.query("t > 0").dp.max()
    scalars['Pmax'] = dfpl.query("t > 0").dp.max()*Vdot
    scalars['Qgen'] = dfener.Qdot_gen.sum()
    scalars['T_cellmax'] = dfcell.Tcell.max()
    scalars['t21'] = T.query(f"t>{t_peak} & Tcell<{21+273.15}").t.min()  # time when worst cell is below 21 again
    scalars['t45'] = T.query(f"t>{t_peak} & Tcell<{45+273.15}").t.min()  # time when worst cell is below 45 again
    scalars['tpeak'] = T.t.loc[T.Tcell.idxmax()]                         # time of peak temp
    scalars['T_cell1000'] = T.query("t == 1000").Tcell.values[0]
    scalars['T_cell90'] = T.query("t == 90").Tcell.values[0]
    scalars['dhyd'] = dia_hydr_rect(channel_width, channel_height)
    scalars['Re'] = reynolds(fluid.eta, fluid.rho, v, dhyd)
    
    # can turn this back to dict with `d.to_dict(orient='index')` 
    return scalars