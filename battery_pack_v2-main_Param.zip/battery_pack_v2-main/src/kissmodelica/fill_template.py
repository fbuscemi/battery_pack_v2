from string import Template
import json
import os 
import argparse

MO_TEMPLATE = "Kiss1.mo.tmpl"
MOS_TEMPLATE = "kiss1.mos.tmpl"

parser = argparse.ArgumentParser()
parser.add_argument("infile", type=str, help="json data input")
parser.add_argument("mo_path", type=str, help="modelica file")
parser.add_argument("mos_path", type=str, help="modelica script file")
args = parser.parse_args()

# read input
with open(args.infile, "r", encoding="utf-8") as fp:
    d = json.load(fp)

# write modelica
with open(MO_TEMPLATE, encoding="utf-8") as fp:
    tmo = Template(fp.read())
with open(args.mo_path, "w", encoding="utf-8") as fp:
    fp.write(tmo.substitute(d))

# write modelica script
with open(MOS_TEMPLATE, encoding="utf-8") as fp:
    tmos = Template(fp.read())
with open(args.mos_path, "w", encoding="utf-8") as fp:
    fp.write(tmos.substitute(d))

