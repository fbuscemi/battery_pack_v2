# diagrams with plotly

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import re



def plot_tcell(df, tmax=np.inf, step=10, degC=True, k="both", figsize=(12,6)):
    """Return a matplotlib plot of cell temperatures"""
    if degC:
        label = "T (°C)"
        col = "TcellC"
    else:
        label = "T (K)"
        col = "Tcell"
        
    ncells = df.i.max() + 1
    nrows = df.j.max() + 1
    
    fig, axes = plt.subplots(nrows=nrows, ncols=ncells, figsize=figsize, 
                             constrained_layout=True, 
                             sharex=True, sharey=True)
    fig.suptitle("Cell Temperatures")
    
    for i in range(ncells):
        for j in range(nrows):
            ax = axes[j][i]
            df_ = df.query(f"i=={i} & j=={j} & k==0 & t<{tmax} & t%{step}==0")
            df_.plot(ax=ax, x="t", y=col, legend=False)
            ax.grid()
            ax.set_xlabel("t (s)")
            ax.set_ylabel(label)
            
    return fig   


def plot_tfluid(df, tmax=np.inf, step=1, pos=2, degC=True, figsize=(12,6)):

    """Return a matplotlib plot of cell temperatures"""
    if degC:
        label = "T (°C)"
        col = "TfluidC"
    else:
        label = "T (K)"
        col = "Tfluid"
        
    npipes = df['pipe'].max() + 1
    nbars = df['bar'].max() + 1
    
    fig, axes = plt.subplots(nrows=npipes, ncols=nbars, figsize=figsize, 
                             constrained_layout=True, 
                             sharex=True, sharey=True)
    fig.suptitle("Fluid Temperatures")
    
    for i in range(npipes):
        for j in range(nbars):
            ax = axes[i][j]
            df_ = df.query(f"pipe=={i} & bar=={j} & pos=={pos} & t<{tmax} & t%{step}==0")
            df_.plot(ax=ax, x="t", y=col, legend=False)
            ax.grid()
            ax.set_xlabel("t (s)")
            ax.set_ylabel(label)
            
    return fig   



def plot_twall(df, tmax=np.inf, step=1, degC=False, figsize=(12,6)):
    """Return a matplotlib plot of wall temperatures"""

    if degC:
        label = "T (°C)"
        col = "TwallC"
    else:
        label = "T (K)"
        col = "Twall"

    nwalls = df['wall'].max() + 1
    nbars = df['bar'].max() + 1
    
    fig, axes = plt.subplots(nrows=nwalls, ncols=nbars, figsize=figsize, 
                             constrained_layout=True, 
                             sharex=True, sharey=True)
    fig.suptitle("Wall Temperatures (Wall between pipes)")
    
    df_ = df.query(f't < {tmax} & t % {step} == 0')
    
    for i in range(nwalls):
        for j in range(nbars):
            ax = axes[i][j]
            df_.query(f"wall=={i} & bar=={j}").plot(ax=ax, x="t", y=col, legend=False)
            ax.grid()
            ax.set_xlabel("t (s)")
            ax.set_ylabel(label)
            
    return fig   



def plot_qwall(df, tmax=np.inf, step=1, figsize=(12,6)):
    """Return a wall heat flow plot"""


    nwalls = df['wall'].max() + 1
    nbars = df['bar'].max() + 1
    
    fig, axes = plt.subplots(nrows=nwalls, ncols=nbars, figsize=figsize, 
                             constrained_layout=True, 
                             sharex=True, sharey=True)
    fig.suptitle("Heat flow in plate between pipes")
    
    # limit to time < tmax and front side, and select every xth
    df_ = df.query(f't < {tmax} & t % {step} == 0')
    
    for i in range(nwalls):
        for j in range(nbars):
            ax = axes[i][j]
            df_.query(f"wall=={i} & bar=={j} & port=='a'").plot(ax=ax, x="t", y="Q_flow", label="port: a")
            df_.query(f"wall=={i} & bar=={j} & port=='b'").plot(ax=ax, x="t", y="Q_flow", label="port: b")
            ax.grid()
            ax.set_xlabel("t (s)")
            ax.set_ylabel('$\dot{Q}$ (W)')
            
    return fig       



def plot_qpipe(df, tmax=np.inf, step=1, figsize=(12,6)):
    """Return a diagram showing heat flow rate from cells to pipe."""

    nrows = df['j'].max() + 1
    ncols = df['i'].max() + 1

    fig, axes = plt.subplots(nrows=nrows, ncols=ncols, figsize=figsize, 
                             constrained_layout=True, 
                             sharex=True, sharey=True)
    fig.suptitle("Heat flow from cells into pipe")
    
    df_ = df.query(f't < {tmax} & t % {step} == 0')
    
    for i in range(ncols):
        for j in range(nrows):
            ax = axes[j][i]
            df_.query(f"i=={i} & j=={j}").plot(ax=ax, x="t", y="Q_flow", legend=False)
            ax.grid()
            ax.set_xlabel("t (s)")
            ax.set_ylabel('$\dot{Q}$ (W)')
            
    return fig   



def plot_tfluid_s(df, timepoints=[30, 60, 90, 300, 600, 1200], pos=1, degC=False, figsize=(12,6)):
    """Plot fluid temp over pipe length"""
    # NOTE: it's not really pipe length but quarter cell count
    # pos: the internal note in the pipe we're investigating


    ncells = 1 + df['bar'].max() 
    npipes = 1 + df['pipe'].max()

    # TODO: separate data preparation (same for plotly and matplotlib) from plotting
    # TODO: currently this works only for npipes == 4. adapt this for more genral designs.
    assert npipes == 4, "npipes != 4 "

    x = []

    for t in timepoints:
        # pipe j = 0 (upper)
        r = df.query(f"t == {t} & pipe == 0 & pos == {pos}").sort_values(by="bar", ascending=True)
        r['s'] = np.arange(ncells)
        x.append(r)
        # j = 1
        r = df.query(f"t == {t} & pipe == 1 & pos == {pos}").sort_values(by="bar", ascending=False)
        r['s'] = np.arange(ncells, 2*ncells)
        x.append(r)        
        # j = 1
        r = df.query(f"t == {t} & pipe == 2 & pos == {pos}").sort_values(by="bar", ascending=True)
        r['s'] = np.arange(2*ncells, 3*ncells)
        x.append(r)
        # pipe = 3 (lower)
        r = df.query(f"t == {t} & pipe == 3 & pos == {pos}").sort_values(by="bar", ascending=False)
        r['s'] = np.arange(3*ncells, 4*ncells)
        x.append(r)

    if degC:
        ylabel = "T (°C)"
        col = "TfluidC"
    else:
        ylabel = "T (K)"
        col = "Tfluid"

    dfx = pd.concat(x, ignore_index=False)

    fig, ax = plt.subplots(figsize=figsize)
    for t in timepoints:
        dfx.query(f"t=={t}").plot(ax=ax, x="s", y=col, label=f"{t} s", legend=True)
    ax.grid()
    ax.set_xlabel("Pipe length (number of cells crossed)")
    ax.set_ylabel(ylabel)
    ax.set_title("Fluid temperature vs. pipe length")
    return fig  


def plot_deltap(df, tmax=np.inf, step=1, figsize=(12,6)):
    """Plot pressure loss over time. """
    # NOTE: use t>0 to avoid peak at the beginning.
    fig, ax = plt.subplots(figsize=figsize)
    df.query(f"t > 0 & t <= {tmax} & t%{step} == 0").plot(ax=ax, x="t", y="dp", legend=False)
    ax.grid()
    ax.set_xlabel("t (s)")
    ax.set_ylabel('$\Delta p$ (Pa)')
    ax.set_title("Pressure loss")
    return fig
 

def plot_energies(df, tmax=np.inf, step=1, ignore_t0=True, figsize=(12,6)):
    df_ = df.query("t > 0") if ignore_t0 else df
    fig, ax = plt.subplots(figsize=figsize)
    columns = df.columns.drop("t")
    #for col in columns:
    df.query(f"t%{step}==0 & t<{tmax}").plot(ax=ax, x="t", y=columns, legend=True)
    ax.grid()
    ax.set_xlabel("t (s)")
    ax.set_ylabel("Power (W)")
    ax.set_title("Energy flow")    
    return fig
