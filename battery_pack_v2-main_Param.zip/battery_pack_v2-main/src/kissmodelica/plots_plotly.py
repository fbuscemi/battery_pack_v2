# diagrams with plotly

import numpy as np
import pandas as pd
import plotly.express as px
import re


def plot_tcell(df, tmax=np.inf, step=1, k=0, degC=False):

    # limit to time < tmax and front side, and select every xth
    df_ = df.query(f't < {tmax} & k=={k} & t % {step} == 0')
    
    if degC:
        label = "T (°C)"
        col = "TcellC"
    else:
        label = "T (K)"
        col = "Tcell"

    fig = px.line(df_, x="t", y=col, 
                  labels={"t": "Time (s)", col: label},
                  facet_row="j",
                  facet_col="i",
                  line_group="k",
                  color="k",              
                  title=f'Cell Temperatures')
    return fig


def plot_tcell_minmax(df, tmax=np.inf, step=1, degC=False):

    if degC:
        label = "T (°C)"
        col = "TcellC"
        dropcol = "Tcell"
    else:
        label = "T (K)"
        col = "Tcell"
        dropcol = "TcellC"
    
    # limit to time < tmax and front side, and select every xth
    grouped = df.query(f't < {tmax} & t % {step} == 0')\
                .drop(columns=["i", "j", "k", dropcol])\
                .groupby(by=["t"])
    df_ = pd.merge(grouped.min(), grouped.max(), on="t", suffixes=["_min", "_max"]) 
    
    fig = px.line(df_, y=df_.columns,
                  labels={"t": "Time (s)", 'value': label},
                  title=f'Min/Max Cell Temperatures')
    return fig


def plot_tfluid(df, tmax=np.inf, step=1, pos=2, degC=False):

    # limit to time < tmax and front side, and select every xth
    df_ = df.query(f't < {tmax} & pos=={pos} & t % {step} == 0')
    
    if degC:
        label = "T (°C)"
        col = "TfluidC"
    else:
        label = "T (K)"
        col = "Tfluid"

    fig = px.line(df_, x="t", y=col, 
                  labels={"t": "Time (s)", col: label},
                  facet_row="pipe",
                  facet_col="bar",
                  title=f'Fluid Temperatures')
    return fig


def plot_twall(df, tmax=np.inf, step=1, degC=False):

    # limit to time < tmax and front side, and select every xth
    df_ = df.query(f't < {tmax} & t % {step} == 0')
    
    if degC:
        label = "T (°C)"
        col = "TwallC"
    else:
        label = "T (K)"
        col = "Twall"

    fig = px.line(df_, x="t", y=col, 
                  labels={"t": "Time (s)", col: label},
                  facet_row="wall",
                  facet_col="bar",
                  title=f'Wall Temperatures')
    return fig


def plot_qwall(df, tmax=np.inf, step=1):

    # limit to time < tmax and front side, and select every xth
    df_ = df.query(f't < {tmax} & t % {step} == 0')

    # latex doesn't seam to work in plotly??
    fig = px.line(df_, x="t", y="Q_flow",    
                labels={'Q_flow': 'Q_dot (W)', "t": "t (s)"},
                facet_row="wall",
                facet_col="bar",
                line_group="port",
                color="port",
                title='Heat flow in plate between pipes')
    return fig


def plot_qpipe(df, tmax=np.inf, step=1):

    # limit to time < tmax and front side, and select every xth
    df_ = df.query(f't < {tmax} & t % {step} == 0')

    # latex doesn't seam to work in plotly??
    fig = px.line(df_, x="t", y="Q_flow",    
                labels={'Q_flow': 'Q_dot (W)', "t": "t (s)"},
                facet_row="j",
                facet_col="i",
                title='Heat flow from cells into pipe')
    return fig


# FIXME: this function is buggy - it does not work with 1-based indexing for bars.
# workaround: pass this into the function
# df_ = df_tfluid.copy()
# df_.bar -= 1

def plot_tfluid_s(df, timepoints=[30, 60, 90, 300, 600, 1200], pos=1, degC=False):
    """Plot fluid temp over pipe length"""
    # NOTE: it's not really pipe length but quarter cell count
    # pos: the internal note in the pipe we're investigating


    ncells = df['bar'].max() # bars are now a 1-based array...
    npipes = 1 + df['pipe'].max()

    # TODO: currently this works only for npipes == 4. adapt this for more genral designs.
    assert npipes == 4, "npipes != 4 "

    x = []

    for t in timepoints:
        # pipe j = 0 (upper)
        r = df.query(f"t == {t} & pipe == 0 & pos == {pos}").sort_values(by="bar", ascending=True)
        r['s'] = np.arange(ncells)
        x.append(r)
        # j = 1
        r = df.query(f"t == {t} & pipe == 1 & pos == {pos}").sort_values(by="bar", ascending=False)
        r['s'] = np.arange(ncells, 2*ncells)
        x.append(r)        
        # j = 1
        r = df.query(f"t == {t} & pipe == 2 & pos == {pos}").sort_values(by="bar", ascending=True)
        r['s'] = np.arange(2*ncells, 3*ncells)
        x.append(r)
        # pipe = 3 (lower)
        r = df.query(f"t == {t} & pipe == 3 & pos == {pos}").sort_values(by="bar", ascending=False)
        r['s'] = np.arange(3*ncells, 4*ncells)
        x.append(r)

    if degC:
        label = "T (°C)"
        col = "TfluidC"
    else:
        label = "T (K)"
        col = "Tfluid"

    dfx = pd.concat(x, ignore_index=False)
    fig = px.line(dfx, x="s", y=col,
                  labels={col: label, "s": "cell crossing"},
                  line_group="t",
                  color="t",
                  title='Fluid temperature vs. pipe length')  
    return fig  


def plot_deltap(df, tmax=np.inf, step=1):
    """Plot pressure loss over time. """
    # NOTE: use t>0 to avoid peak at the beginning.
    return px.line(df.query(f"t > 0 & t <= {tmax} & t%{step} == 0"), 
                   x="t", y="dp",     
                   labels={'dp': 'Delta p (Pa)', "t": "t (s)"},
                   title='Pressure loss'
                   )
 

def plot_energies(df, tmax=np.inf, step=1, ignore_t0=True):
    df_ = df.query("t > 0") if ignore_t0 else df
    return px.line(df_.query(f"t%{step}==0 & t<{tmax}"), 
                    labels={"t": "t (s)", "value": "Power (W)"},
                    x="t", y=df.columns.drop("t"),
                    title='Energy flow')