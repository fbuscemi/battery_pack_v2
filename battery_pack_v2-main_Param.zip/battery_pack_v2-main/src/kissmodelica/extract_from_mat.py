import json
import os 
import argparse

import DyMat
from . import postproc

parser = argparse.ArgumentParser()
parser.add_argument("infile", type=str)
parser.add_argument("matfile", type=str)
parser.add_argument("outfile", type=str)
args = parser.parse_args()

# read input
with open(args.infile, encoding="utf-8") as fp:
    inp_data = json.load(fp)

# read modelica result
if os.path.exists(args.matfile):
    try:
        res = DyMat.DyMatFile(args.matfile)    
        d = postproc.extract_scalar_values2(res, **inp_data)
    except ValueError:
        d = {"status": "error"}

# write output
with open(args.outfile, "w", encoding="utf-8") as fp:
    json.dump(d, fp, indent=2)