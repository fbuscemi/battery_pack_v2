# Postprocessing and Visualisation

## Individual Design

should be possible for one rack, or all racks

- show 3d model
- show 2d views: 
  - querschnitt kühlplatte (form des kanals, wanddicke)
  - draufsicht kühlplatte (schlange, radien)
- eingangsparameter (volumenstrom, rohrquerschnitt, wanddicken, materialkennwerte, zeitl. verlauf des stroms)
- temperatur vs. zeit für zellen
- temperatur der wände über zeit
- Druck, Re, Nu, Pr - räuml. verlauf im kühlkanal
- Wärmeströme: 
  - von zelle ins wasser
  - zwischen den kanälen
  - speicherung in zellen und wänden
- animation zelltemperatur über zeit

## Vergleich verschiedener Entwürfe

- durchschnittliche, min/max zelltemperatur (per rack)
- druckverlust total, Re, ...
- max. zelltemperatur nach 1000 s 
- eingangsparameter
- individuelle zelltemperaturen
