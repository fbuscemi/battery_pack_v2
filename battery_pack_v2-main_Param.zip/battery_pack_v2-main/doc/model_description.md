# Kiss Battery Model

![alt text](All.JPG "Battery Pack overview")

## Description of battery

The battery pack consists of 9 racks, and 140 cells total. (Last rack: 
4 cells missing)

Each racks consists of 
- 2 aluminium plates (a 6 mm thick one with the cooling channel, light blue,
  and a 2 mm thin one the closes it, dark blue)
- 16 battery cells (8 om each side).

![alt text](rack.png "one rack")

Further information:
- [CAD model](https://drive.google.com/file/d/1FuEZgo1fN1g1zlpC2dTb6hr2x3eCHonp/view?usp=sharing)
- [system description](https://docs.google.com/document/d/1ctgwckXKFOVCsTbGglB4ufbkGCjX_JtFagn6xUiasj0/)



## Description of model

![alt text](kiss_model.png "model of one rack")

The model is used to simulate the temperature time history of the battery cells.
The model represents one rack with 16 battery cells.

The model has several subcomponents, which are described below.

### PouchCellAndPipe

![alt text](bar.png "a bar")

![alt text](sec_thru_bar.png "a section through caells and plates, showing cooling channels")

![alt text](pouchcellandpipe.png "pouch cell and pipe")

This element of the model represents two battery cells, and the cooling 
element between. In other words 1/8 of a rack.

The four pipe elements represent the four passes of the cooling channel over the battery cell.

Each CooledPouchCell in the block represents 2 quarter battery cells. 

The material between the pipes is modeled as well (as walls).

Nomenclature of quarter battery cells:

![naming schema](nomenclature.png "naming schema")


### CooledPouchCell

![alt text](cooledpouchcell.png "cooled pouch cell model")

This component describes the heat transfer of two attached battery cells (actually quarter battery cells) to the cooling channel.


### PouchZelle

![alt text](pouchzelle.png "cooled pouch cell model")

This is a model for 1/4 battery cell.

The left part models the electrical current and the resulting generated heat.
The right part describes the heat capacity of the battery cell and the thermal resistance 
of the contact between the battery cell and the adjacent cooling element (al plate).


### Wand

An element for heat conduction. Used in two places:

1. heat conduction inside Al plate, between two adjacent channels
2. heat condiction through Al plate, from battery cell to fluid channel



### PouchWaermemenge

This is a model for heat generation in 1/4 battery cell, $\dot Q = \frac{1}{4} R_i I^2$.



## Model Parameters

| Element | Parameter | Value | Unit | description |
| ---  | --- | --- | --- | --- |
| CooledPouchCell.wand[01] | area_h | 3.44e-4 | m² | area over which heat is transferred from cell to fluid. Battery width times pipe width |
| CooledPouchCell.wand[01] | s | 0.002 | m | wall thickness |
| PouchCellAndPipe.pipe[0-3] | crossArea | 0.32e-4 | m² | rectangular pipe, width x height |
| PouchCellAndPipe.pipe[0-3] | perimeter | 0.024 | m | rectangular pipe, 2 x (width + height) |
| PouchCellAndPipe.wand[0-2] | area_h | 1.72e-4 | m² | area over which heat is transferred from one pipe to the adjacent one. Width of battery cell times pipe height |
| PouchCellAndPipe.wand[0-2] | s | 0.04 | m | thickness of wall between pipes. Note that original model uses distance between pipe centre lines |
| Kiss1.boundary0 | m_flow | 0.0037 | kg/s | mass flow rate for one rack |
