# Geometry creation

Model has the following parameters (rectangular cooling channels):

1. number of racks (1..9)
2. number of cells per rack (2 x 2..inf)
3. cooling channel width (>0..25) 
4. cooling channel height (>0..10)
5. wall thickness (amount of alumimium between battery cell and fluid) (>0..10)

## Workflow

The basic idea is that a computer (or a human) calls a program (Rhino) on the command line, 
with two parameters:

1. name of input file
2. target directory for output

Rhino (or some script) takes the input, and creates output as specified. No UI interaction required.


## Input

a json file containing the parameters above, like:

```
{
    'assy_id': 's12rlksglkg896',
    'nracks': 9,
    'ncells': 8,
    'channel_width': 12.0,
    'channel_height': 2.0,
    'twall': 1.2
}
```

## Output

### Metadata

these data serve as input for modelica, and for traceability.
as a json file, containing:

- name of grasshopper model (github link)
- version of grasshopper model (branch, commit id)
- timestamp (current time when program was run)
- copy of input parameters
- length of heat transfer area btwn. cell and pipe (= battery width)
- distance (in x) between two battery cells (kleine Rippe)
- distance (in y) between two cooling channels (mid line)
- // radius of cooling channel bends (mid line) -> halbkreis, also halber abstand


### 3D Models

The complete battery pack assembly as a single step file, for detailed studies

- parts named after a clear scheme

Additionally:
- 1 3d model per part
- fully positioned in 3d
- named by part_id (1.obj ,2.obj, ...)
- as obj
- same as step 


### Part List

- as csv
- columns
  - part_id (1 ...), same id as used for 3D models
  - part type: `cell`, `thin_plate`, `thick_plate` (plus others, as needed)
  - rack number (1...). N/A for parts that are not rack-specific
  - bar number (i = 1..). N/A for parts that are not bar-specific
  - side (k=1 or 2), relevant for cells only, N/A for others
  - Description (human readable)
  - Mass
  - Volume
  - Material
  - others as required


## File layout

```
directory: 's12rlksglkg896'
| input.json
| result.json
| parts.csv
| assy.step
| obj 
       | 1.obj
       | 2.obj
       | ...
| step 
       | 1.step
       | 2.step
       | ...

```


Example Data:

https://drive.google.com/drive/folders/1i8Ujk0dU5HwWZxUTlM9HHJzkHuGmX0kt?usp=sharing
CAD FILES AUS GRASSHOPPER
