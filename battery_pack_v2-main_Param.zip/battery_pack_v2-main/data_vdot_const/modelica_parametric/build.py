# OK, Apr 2021
# This works under both linux and windows
# It works with openmodelica 1.16, but not with openmodelica 1.17: There is an 
# error message related to the modelica standard library version (3.2.3 in 1.16 
# vs. 4.0.0 in 1.17) 

from string import Template
import subprocess

# nracks, ncells
configs = [
    # (2, 35), (3, 24), (4, 18), (5, 14), (6, 12), 
    (7, 10), (8, 9), 
           (9, 8), (10, 7), (12, 6), 
           #(14, 5), (18, 4), (24, 3), (35, 2)
    ]

mos_template = Template("""
    loadModel(Modelica); getErrorString();
    loadFile("Wand.mo"); getErrorString();
    loadFile("PouchZelle.mo"); getErrorString();
    loadFile("CooledPouchCell.mo"); getErrorString();
    loadFile("PouchCellAndPipe.mo"); getErrorString();
    loadFile("Kiss${nracks}x${ncells}.mo"); getErrorString();
    buildModel(Kiss${nracks}x${ncells}); getErrorString();
""")

with open("Kiss_tmpl.mo", encoding="utf-8") as fp:
    tmpl = Template(fp.read())

for nracks, ncells in configs:
    print(f"nracks = {nracks}, ncells = {ncells}\n\n")
    # create main modelica file
    mo = tmpl.substitute(nracks=nracks, ncells=ncells)
    with open(f"Kiss{nracks}x{ncells}.mo", "w", encoding="utf-8") as fp:
        fp.write(mo)

    # create mos script
    mos = mos_template.substitute(nracks=nracks, ncells=ncells)
    with open(f"compile{nracks}x{ncells}.mos", "w", encoding="utf-8") as fp:
        fp.write(mos)

    # run
    subprocess.run(["omc", f"compile{nracks}x{ncells}.mos"])