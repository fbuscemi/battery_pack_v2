import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="kissmodelica", 
    version="0.0.3",
    author="Oliver Koch",
    author_email="okoch@apworks.tech",
    description="Scripts around KISS1 battery pack",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/okozef/battery_pack_v2",
    project_urls={
        "Bug Tracker": "https://github.com/okozef/battery_pack_v2/issues",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: POSIX :: Linux",
    ],
    package_dir={"": "src"},
    packages=setuptools.find_packages(where="src"),
    setup_requires=["wheel"],
    install_requires=["numpy", "scipy", "pandas", "DyMat", "matplotlib", "plotly"],
    python_requires=">=3.6",
)